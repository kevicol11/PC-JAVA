package FACHADA;

public class HardDriver {
    public void read(){
        System.out.println(" hard drive: reading ");
    }
}
