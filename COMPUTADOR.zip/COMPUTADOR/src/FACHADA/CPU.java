package FACHADA;

public class CPU {
    public void freeze(){
        System.out.println(" cpu freezing... ");
    }
    public void execute(){
        System.out.println(" cpu executing.... ");
    }
    public void jump(){
        System.out.println(" cpu : jumping... ");
    }
}
