package FACHADA;

public class Memory {
    public void load(){
        System.out.println(" memory loding... ");
    }
}
