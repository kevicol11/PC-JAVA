import FACHADA.ComputerFacade;

public class App {
    public static void main(String[] args) throws Exception {
        ComputerFacade computer = new ComputerFacade();
        computer.star();
    }
}
